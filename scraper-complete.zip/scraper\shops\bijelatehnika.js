// BijelaTehnika.com scraper
const cookies = require('../utils/cookies');
const { parsePrice } = require('../utils/price');

module.exports = {
    name: 'BijelaTehnika',
    baseUrl: 'https://bijelatehnika.com',

    async getRandomProducts(browser, count = 10) {
        const page = await browser.newPage();

        try {
            await cookies.setCookies(page);

            console.log('BijelaTehnika: Fetching random products...');

            await page.goto('https://bijelatehnika.com/', {
                waitUntil: 'networkidle2',
                timeout: 30000
            });

            await page.waitForTimeout(2000);

            const products = await page.evaluate(() => {
                const results = [];
                const items = document.querySelectorAll('.product-item, .product-card, .product, [class*="product"]');

                for (const item of items) {
                    const nameEl = item.querySelector('.product-name, .product-title, h2, h3');
                    const priceEl = item.querySelector('.price, .product-price, [class*="price"]');
                    const linkEl = item.querySelector('a[href*="/product"], a[href*="/proizvod"]');

                    if (nameEl && priceEl && linkEl) {
                        results.push({
                            name: nameEl.innerText.trim(),
                            price: priceEl.innerText.trim(),
                            url: linkEl.href
                        });
                    }
                }

                return results;
            });

            await page.close();

            // Shuffle and take random products
            const shuffled = products.sort(() => 0.5 - Math.random());
            const selected = shuffled.slice(0, Math.min(count, products.length));

            return selected.map(p => ({
                name: p.name,
                price: parsePrice(p.price)
            }));

        } catch (error) {
            console.error('BijelaTehnika error:', error.message);
            await page.close();
            return [];
        }
    }
};

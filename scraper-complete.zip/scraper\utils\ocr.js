// OCR processing for invoices and images
const Tesseract = require('tesseract.js');
const fs = require('fs');

module.exports = {
    async extractText(filePath) {
        try {
            console.log('OCR: Processing file:', filePath);

            const { data: { text } } = await Tesseract.recognize(
                filePath,
                'bos+eng',
                {
                    logger: info => {
                        if (info.status === 'recognizing text') {
                            console.log(`OCR Progress: ${Math.round(info.progress * 100)}%`);
                        }
                    }
                }
            );

            console.log('OCR: Completed. Text length:', text.length);
            return text;
        } catch (error) {
            console.error('OCR Error:', error);
            throw error;
        }
    },

    parseProducts(ocrText) {
        const lines = ocrText.split('\n');
        const products = [];

        for (let line of lines) {
            line = line.trim();
            if (line.length < 5) continue;

            // Match price patterns: 1.234,56 or 1234,56 or 1234.56
            const pricePattern = /(\d{1,5}[.,]\d{2})\s*(KM|BAM|km|bam)?/gi;
            const priceMatches = [...line.matchAll(pricePattern)];

            if (priceMatches.length === 0) continue;

            // Get the last price (usually unit price, not total)
            const lastPrice = priceMatches[priceMatches.length - 1];
            const priceStr = lastPrice[1].replace(',', '.');
            const price = parseFloat(priceStr);

            if (price <= 0 || price > 100000) continue;

            // Extract product name (text before price)
            const priceIndex = line.indexOf(lastPrice[0]);
            let productName = line.substring(0, priceIndex).trim();

            // Clean product name
            productName = productName
                .replace(/^\d+\s*/, '') // Remove leading numbers
                .replace(/\b(R1|R2|R3|JM|KOM|kom|kom\.|pdv|PDV|VAT|%)\b/gi, '')
                .replace(/\s+/g, ' ')
                .trim();

            // Validate product name
            if (productName.length < 5) continue;
            if (/^(ukupno|total|pdv|vat|poreз|rabat|discount)/i.test(productName)) continue;

            products.push({
                name: productName,
                price: Math.round(price * 100) / 100
            });
        }

        console.log(`OCR: Parsed ${products.length} products`);
        return products;
    },

    async parseInvoice(filePath) {
        const text = await this.extractText(filePath);
        const products = this.parseProducts(text);

        return {
            rawText: text,
            products: products
        };
    }
};

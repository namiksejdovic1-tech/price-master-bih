// Domod.ba scraper
const cookies = require('../utils/cookies');
const { parsePrice } = require('../utils/price');
const { matchProducts } = require('../utils/fuzzy');

module.exports = {
    name: 'Domod',
    baseUrl: 'https://domod.ba',

    async scrape(browser, productName) {
        const page = await browser.newPage();

        try {
            await cookies.setCookies(page);

            const searchUrl = `https://domod.ba/pretraga?keywords=${encodeURIComponent(productName)}`;
            console.log(`Domod: Searching ${searchUrl}`);

            await page.goto(searchUrl, {
                waitUntil: 'networkidle2',
                timeout: 30000
            });

            await page.waitForTimeout(2000);

            const products = await page.evaluate(() => {
                const results = [];
                const items = document.querySelectorAll('.product-item, .product-card, .product, [class*="product"]');

                for (const item of items) {
                    const nameEl = item.querySelector('.product-name, .product-title, h2, h3, a[href*="/product"]');
                    const priceEl = item.querySelector('.price, .product-price, [class*="price"]');
                    const linkEl = item.querySelector('a[href*="/product"], a[href*="/proizvod"]');

                    if (nameEl && priceEl && linkEl) {
                        results.push({
                            name: nameEl.innerText.trim(),
                            price: priceEl.innerText.trim(),
                            url: linkEl.href
                        });
                    }
                }

                return results;
            });

            await page.close();

            // Find best match
            let bestMatch = null;
            let bestScore = 0;

            for (const product of products) {
                const match = matchProducts(productName, product.name);
                if (match.match && match.score > bestScore) {
                    bestScore = match.score;
                    bestMatch = product;
                }
            }

            if (bestMatch) {
                const price = parsePrice(bestMatch.price);
                console.log(`Domod: Found ${bestMatch.name} - ${price} KM (score: ${bestScore})`);
                return {
                    found: true,
                    price: price,
                    url: bestMatch.url,
                    productName: bestMatch.name,
                    matchScore: bestScore
                };
            }

            console.log('Domod: No match found');
            return { found: false, price: 0, url: '', productName: '', matchScore: 0 };

        } catch (error) {
            console.error('Domod scrape error:', error.message);
            await page.close();
            return { found: false, price: 0, url: '', productName: '', matchScore: 0 };
        }
    }
};

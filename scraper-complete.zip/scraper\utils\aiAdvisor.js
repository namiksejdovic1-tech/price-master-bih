// AI pricing advisor
module.exports = {
    analyze(myPrice, competitorPrices) {
        const validPrices = competitorPrices.filter(p => p > 0);

        if (validPrices.length === 0) {
            return {
                recommendation: myPrice,
                strategy: 'no_data',
                message: 'Nema dostupnih cijena konkurencije',
                competitiveIndex: 50
            };
        }

        const minPrice = Math.min(...validPrices);
        const maxPrice = Math.max(...validPrices);
        const avgPrice = validPrices.reduce((a, b) => a + b, 0) / validPrices.length;

        let recommendation = myPrice;
        let strategy = 'maintain';
        let message = 'Održi trenutnu cijenu';

        // Calculate competitive index (0-100)
        let competitiveIndex = 50;
        if (myPrice < minPrice) {
            competitiveIndex = 100;
            strategy = 'raise';
            recommendation = Math.round((minPrice - 1) * 100) / 100;
            message = `Možeš povećati na ${recommendation} KM (ispod konkurencije)`;
        } else if (myPrice > maxPrice) {
            competitiveIndex = 0;
            strategy = 'lower';
            recommendation = Math.round(avgPrice * 100) / 100;
            message = `Smanji na ${recommendation} KM (prosječna cijena tržišta)`;
        } else {
            // Price is within range
            const position = (myPrice - minPrice) / (maxPrice - minPrice);
            competitiveIndex = Math.round((1 - position) * 100);

            if (myPrice < avgPrice) {
                strategy = 'competitive';
                message = `Odlična cijena! ${Math.round(competitiveIndex)}% konkurentnije od prosjeka`;
            } else if (myPrice > avgPrice) {
                strategy = 'high';
                recommendation = Math.round(avgPrice * 100) / 100;
                message = `Razmisli o smanjenju na ${recommendation} KM`;
            } else {
                strategy = 'maintain';
                message = 'Na prosječnoj cijeni tržišta';
            }
        }

        return {
            recommendation: Math.round(recommendation * 100) / 100,
            strategy,
            message,
            competitiveIndex: Math.max(0, Math.min(100, competitiveIndex)),
            marketData: {
                min: Math.round(minPrice * 100) / 100,
                max: Math.round(maxPrice * 100) / 100,
                avg: Math.round(avgPrice * 100) / 100
            }
        };
    }
};

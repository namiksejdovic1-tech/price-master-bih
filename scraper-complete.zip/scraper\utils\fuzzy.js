// Fuzzy matching for product names
const fuzz = require('fuzzball');

module.exports = {
    normalizeProductName(name) {
        return name
            .toLowerCase()
            .replace(/[^a-z0-9\s]/g, '')
            .replace(/\s+/g, ' ')
            .trim();
    },

    extractModelNumber(name) {
        // Extract model numbers, serial numbers
        const matches = name.match(/\b([a-z]{1,3}[-]?\d{2,}[a-z]?\d*)\b/gi);
        return matches ? matches : [];
    },

    extractBrand(name) {
        const brands = [
            'samsung', 'lg', 'sony', 'apple', 'iphone', 'ipad',
            'bosch', 'siemens', 'miele', 'gorenje', 'tesla',
            'xiaomi', 'huawei', 'lenovo', 'asus', 'acer',
            'hp', 'dell', 'microsoft', 'playstation', 'xbox'
        ];

        const normalized = this.normalizeProductName(name);
        for (const brand of brands) {
            if (normalized.includes(brand)) {
                return brand;
            }
        }
        return null;
    },

    matchProducts(searchName, candidateName, threshold = 70) {
        const searchNorm = this.normalizeProductName(searchName);
        const candidateNorm = this.normalizeProductName(candidateName);

        // Base fuzzy score
        let score = fuzz.partial_ratio(searchNorm, candidateNorm);

        // Boost if model numbers match
        const searchModels = this.extractModelNumber(searchName);
        const candidateModels = this.extractModelNumber(candidateName);

        if (searchModels.length > 0 && candidateModels.length > 0) {
            for (const sm of searchModels) {
                for (const cm of candidateModels) {
                    if (sm.toLowerCase() === cm.toLowerCase()) {
                        score += 20;
                        break;
                    }
                }
            }
        }

        // Brand must match
        const searchBrand = this.extractBrand(searchName);
        const candidateBrand = this.extractBrand(candidateName);

        if (searchBrand && candidateBrand && searchBrand !== candidateBrand) {
            score -= 30;
        }

        return {
            score: Math.min(100, Math.max(0, score)),
            match: score >= threshold
        };
    }
};

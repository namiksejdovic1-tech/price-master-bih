// Ekupi.ba scraper
const cookies = require('../utils/cookies');
const { parsePrice } = require('../utils/price');
const { matchProducts } = require('../utils/fuzzy');

module.exports = {
    name: 'Ekupi',
    baseUrl: 'https://www.ekupi.ba',

    async scrape(browser, productName) {
        const page = await browser.newPage();

        try {
            await cookies.setCookies(page);

            const searchUrl = `https://www.ekupi.ba/bs/search/?text=${encodeURIComponent(productName)}`;
            console.log(`Ekupi: Searching ${searchUrl}`);

            await page.goto(searchUrl, {
                waitUntil: 'networkidle2',
                timeout: 30000
            });

            await page.waitForTimeout(2000);

            const products = await page.evaluate(() => {
                const results = [];
                const items = document.querySelectorAll('.product-item, .product-card, .product, [class*="product"]');

                for (const item of items) {
                    const nameEl = item.querySelector('.product-name, .product-title, h2, h3, a[href*="/p/"]');
                    const priceEl = item.querySelector('.price, .product-price, [class*="price"]');
                    const linkEl = item.querySelector('a[href*="/p/"]');

                    if (nameEl && priceEl && linkEl) {
                        results.push({
                            name: nameEl.innerText.trim(),
                            price: priceEl.innerText.trim(),
                            url: linkEl.href
                        });
                    }
                }

                return results;
            });

            await page.close();

            // Find best match
            let bestMatch = null;
            let bestScore = 0;

            for (const product of products) {
                const match = matchProducts(productName, product.name);
                if (match.match && match.score > bestScore) {
                    bestScore = match.score;
                    bestMatch = product;
                }
            }

            if (bestMatch) {
                const price = parsePrice(bestMatch.price);
                console.log(`Ekupi: Found ${bestMatch.name} - ${price} KM (score: ${bestScore})`);
                return {
                    found: true,
                    price: price,
                    url: bestMatch.url,
                    productName: bestMatch.name,
                    matchScore: bestScore
                };
            }

            console.log('Ekupi: No match found');
            return { found: false, price: 0, url: '', productName: '', matchScore: 0 };

        } catch (error) {
            console.error('Ekupi scrape error:', error.message);
            await page.close();
            return { found: false, price: 0, url: '', productName: '', matchScore: 0 };
        }
    }
};

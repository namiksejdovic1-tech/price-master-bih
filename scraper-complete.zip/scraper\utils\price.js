// Price parsing and normalization utilities
module.exports = {
    parsePrice(priceText) {
        if (!priceText) return 0;

        // Remove currency symbols and text
        let cleaned = priceText
            .replace(/KM|BAM|€|EUR|\$/gi, '')
            .replace(/[^\d.,]/g, '')
            .trim();

        // Handle different formats: 1.234,56 or 1,234.56
        if (cleaned.includes(',') && cleaned.includes('.')) {
            // Determine which is decimal separator
            const lastComma = cleaned.lastIndexOf(',');
            const lastDot = cleaned.lastIndexOf('.');

            if (lastComma > lastDot) {
                // 1.234,56 format
                cleaned = cleaned.replace(/\./g, '').replace(',', '.');
            } else {
                // 1,234.56 format
                cleaned = cleaned.replace(/,/g, '');
            }
        } else if (cleaned.includes(',')) {
            // Only comma - assume decimal separator
            cleaned = cleaned.replace(',', '.');
        }

        const price = parseFloat(cleaned);
        return isNaN(price) ? 0 : Math.round(price * 100) / 100;
    },

    formatPrice(price) {
        return price.toFixed(2) + ' KM';
    }
};
